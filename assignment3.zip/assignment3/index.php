<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="signin.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="signin.css" rel="stylesheet">
</head>
<body>
  <?php
    if (!@$_COOKIE["mycookie_name"]) {
      ?>
  <div id = "main" class = "container" style = "width: 400px" >
    <form class = "form-signin" action="login.php" role = "form" style = "font-size: 200%; font-style: Arial " method="POST">
      <h2 class="form-signin-heading">Please sign in</h2>
      <input type="text" class = "form-control" placeholder="nickname" name="name1" required autofocus><br>
      <input type="password"  class = "form-control" placeholder="password"  name="password1"/><br>
      <input type="submit" value = "Sign in" class="btn btn-lg btn-primary btn-block" style = "font-size: 80%";/>
    </form>

    <form action="register.php" style = "font-size: 200%" method="POST">
      <h2 class="form-signin-heading">Please register</h2>
      <input type="text"  class = "form-control" placeholder="nickname" placeholder="choose a name" name="name2"/><br>
      <input type="password"  class = "form-control" name="password2" placeholder="choose a password"><br>
      <input type="submit" class="btn btn-lg btn-primary btn-block" value = "Register" style = "font-size: 80%"/>
    </form> 
  </div>
<?php } else { ?>
  You already logged in. <a href="logout.php">logout</a>
<?php } ?>
</body>
</html>
