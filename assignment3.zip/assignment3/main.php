<?php
	session_start();
	$_COOKIE['count']?($c = $_COOKIE['count']+1):($c =1);
	setcookie('count',$c);
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="signin.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="signin.css" rel="stylesheet">
</head>
<body>
	<div class = "container" style = "width: 500px">
	<h2>Welcome <?php echo $_COOKIE['mycookie_name']; ?>!<br/>
	You have visited the site <?php echo $_COOKIE['count'] ?> times
	<a href="logout.php"><button class="btn btn-lg btn-primary btn-block" style = "width: 300px">log out</button></a>
	</div>
</body>	
</html>